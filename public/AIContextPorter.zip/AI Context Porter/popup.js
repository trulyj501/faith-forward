document.addEventListener('DOMContentLoaded', function() {
  const langSelect = document.getElementById('lang-select');

  function executeSummary(aiName) {
    const mode = document.querySelector('input[name="mode"]:checked').value;
    const lang = langSelect.value;

    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      const tab = tabs[0];

      if (mode === 'url') {
        const promptText = `다음 웹페이지를 ${lang}로 요약해줘: ${tab.url}`;
        openAI(aiName, promptText, mode);
      } else {
        chrome.scripting.executeScript({
          target: {tabId: tab.id},
          func: () => document.body.innerText
        }, (results) => {
          if (results && results[0] && results[0].result) {
            const pageText = results[0].result;
            const promptText = `다음 텍스트를 ${lang}로 요약해줘:\n\n${pageText}`;
            openAI(aiName, promptText, mode);
          } else {
            alert('텍스트를 추출할 수 없는 페이지입니다.');
          }
        });
      }
    });
  }

  function openAI(aiName, promptText, mode) {
    if (aiName === 'chatgpt') {
      const gptUrl = `https://chatgpt.com/?q=${encodeURIComponent(promptText)}`;
      chrome.tabs.create({ url: gptUrl });
    } else {
      // 제미나이와 클로드는 백그라운드 스크립트로 데이터를 보내서 자동 입력을 처리합니다.
      chrome.runtime.sendMessage({
        action: "open_and_fill",
        aiName: aiName,
        promptText: promptText
      });
    }
  }

  document.getElementById('btn-gpt').addEventListener('click', () => executeSummary('chatgpt'));
  document.getElementById('btn-gemini').addEventListener('click', () => executeSummary('gemini'));
  document.getElementById('btn-claude').addEventListener('click', () => executeSummary('claude'));
});