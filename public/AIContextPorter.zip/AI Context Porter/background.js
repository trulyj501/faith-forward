// 1. 우클릭 메뉴 설정 (링크 우클릭 시)
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "summarize-link-gemini",
    title: "제미나이로 한국어로 요약하기",
    contexts: ["link"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "summarize-link-gemini") {
    const promptText = "다음 링크의 내용을 한국어로 요약해줘: " + info.linkUrl;
    handleAutoFill('gemini', promptText);
  }
});

// 2. 팝업창에서 보낸 자동 입력 요청 받기
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "open_and_fill") {
    handleAutoFill(request.aiName, request.promptText);
  }
});

// 3. 새 탭을 열고 로딩 후 텍스트를 자동 입력하는 핵심 함수
async function handleAutoFill(aiName, promptText) {
  let targetUrl = '';
  if (aiName === 'gemini') targetUrl = 'https://gemini.google.com/app';
  if (aiName === 'claude') targetUrl = 'https://claude.ai/new';

  const newTab = await chrome.tabs.create({ url: targetUrl });

  chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
    if (tabId === newTab.id && changeInfo.status === 'complete') {
      chrome.tabs.onUpdated.removeListener(listener);

      chrome.scripting.executeScript({
        target: { tabId: newTab.id },
        func: injectAutoFill,
        args: [promptText, aiName]
      });
    }
  });
}

// 4. 제미나이/클로드 화면 안에서 실행되는 자동 타이핑 스크립트
function injectAutoFill(text, aiName) {
  // 웹페이지 내부 요소들이 완전히 나타날 때까지 2.5초 여유 있게 대기합니다.
  setTimeout(() => {
    let inputBox;
    if (aiName === 'gemini') {
      inputBox = document.querySelector('rich-textarea div[contenteditable="true"]') || document.querySelector('.ql-editor');
    } else if (aiName === 'claude') {
      inputBox = document.querySelector('div.ProseMirror[contenteditable="true"]');
    }

    if (inputBox) {
      inputBox.focus();
      // 직접 타이핑한 것처럼 텍스트를 집어넣습니다.
      document.execCommand('insertText', false, text);
      
      // 제미나이는 전송 버튼까지 자동으로 누릅니다.
      if (aiName === 'gemini') {
        setTimeout(() => {
          const sendBtn = document.querySelector('.send-button') || document.querySelector('button[aria-label="Send message"]');
          if(sendBtn) sendBtn.click();
        }, 500);
      }
    } else {
      // 만약 구글이나 앤스로픽이 사이트 디자인을 바꿔서 입력창을 못 찾는 경우를 대비한 예비 조치
      const el = document.createElement('textarea');
      el.value = text;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      alert('자동 입력에 실패했습니다. 사이트 구조가 변경되었을 수 있습니다. 대신 내용이 복사되었으니 붙여넣기(Ctrl+V) 해주세요.');
    }
  }, 2500); 
}